# Data dictionary - `Clean_Data`

| Column | Type | Source | Description |
|---|---|---|---|
| Invoice Date | date | raw | Month-end invoice date |
| Location | text | raw | City, Country (8 locations) |
| Manager\|Salesman | text | raw | Combined key, e.g. `Rajiv\|Naeem` |
| Customer Details | text | raw | `Type:Customer`, e.g. `Supermarkets:Spinneys` |
| Product | text | raw | Product / pack size |
| Sale | number | raw | Sales amount (excl. VAT assumed) |
| Cost | number | raw | Cost of sales |
| Month | date (formula) | derived | First day of the invoice month |
| Year | number (formula) | derived | Invoice year |
| Manager | text (formula) | derived | Text before `\|` |
| Salesman | text (formula) | derived | Text after `\|` |
| Customer Type | text (formula) | derived | Supermarkets, Hypermarkets, Hotels, Groceries |
| Customer | text (formula) | derived | Text after `:` |

Definitions: **Cost Ratio** = Cost / Sales. **Gross Profit** = Sales - Cost. **MOM %** = Sales(month) / Sales(previous month) - 1. **VAT** = Total Sales x VAT rate.
