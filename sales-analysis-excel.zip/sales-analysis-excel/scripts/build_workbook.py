"""Builds the sales analysis workbook (formulas + charts) from the raw ERP export.
Usage: python scripts/build_workbook.py <raw_export.xlsx> <output.xlsx>
Then recalculate in Excel (or LibreOffice) so cached values are stored."""
import openpyxl, datetime, pandas as pd
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.chart import LineChart, PieChart, BarChart, Reference
from openpyxl.chart.label import DataLabelList
from openpyxl.utils import get_column_letter as L

import sys
SRC=sys.argv[1] if len(sys.argv)>1 else 'raw_sales_export.xlsx'
OUT=sys.argv[2] if len(sys.argv)>2 else 'Sales_Analysis_Dashboard.xlsx'
wb=openpyxl.load_workbook(SRC)
ws0=wb['Data']

# ---------- cleaned rows ----------
rows=[]
for r in range(13,ws0.max_row+1):
    a=ws0.cell(r,1).value; k=ws0.cell(r,11).value; c=ws0.cell(r,12).value
    if isinstance(a,datetime.datetime) and isinstance(k,(int,float)) and isinstance(c,(int,float)):
        rows.append((a,ws0.cell(r,2).value,ws0.cell(r,5).value,ws0.cell(r,7).value,ws0.cell(r,9).value,k,c))
N=len(rows); LAST=N+1
print('clean rows',N)

# ---------- styles ----------
F='Arial'
NAVY='1B2A4A'
hfont=Font(name=F,bold=True,color='FFFFFF',size=10)
hfill=PatternFill('solid',fgColor=NAVY)
bfont=Font(name=F,size=10)
bold=Font(name=F,size=10,bold=True)
title=Font(name=F,size=16,bold=True,color=NAVY)
sub=Font(name=F,size=9,italic=True,color='666666')
inp=Font(name=F,size=10,bold=True,color='0000FF')
green=Font(name=F,size=10,color='008000')
yfill=PatternFill('solid',fgColor='FFFF00')
tfill=PatternFill('solid',fgColor='E8EDF5')
thin=Side(style='thin',color='BFC7D5')
box=Border(top=thin,bottom=thin,left=thin,right=thin)
NUM='#,##0;(#,##0);-'
PCT='0.0%;(0.0%);-'
MON='mmm-yy'

def hdr(ws,row,col,labels):
    for i,t in enumerate(labels):
        c=ws.cell(row,col+i,t); c.font=hfont; c.fill=hfill; c.border=box
        c.alignment=Alignment(horizontal='center',vertical='center',wrap_text=True)
def put(ws,ref,val,font=bfont,fmt=None,fill=None,border=True,align=None):
    c=ws[ref]; c.value=val; c.font=font
    if fmt: c.number_format=fmt
    if fill: c.fill=fill
    if border: c.border=box
    if align: c.alignment=Alignment(horizontal=align)
    return c
def head(ws,t,s):
    ws.sheet_view.showGridLines=False
    ws['A1']=t; ws['A1'].font=title
    ws['A2']=s; ws['A2'].font=sub
def widths(ws,d):
    for k,v in d.items(): ws.column_dimensions[k].width=v

# ---------- Clean_Data ----------
cd=wb.create_sheet('Clean_Data')
cols=['Invoice Date','Location','Manager|Salesman','Customer Details','Product','Sale','Cost','Month','Year','Manager','Salesman','Customer Type','Customer']
hdr(cd,1,1,cols)
for i,(d,loc,ms,cu,pr,s,c) in enumerate(rows,start=2):
    cd.cell(i,1,d).number_format='d-mmm-yy'
    cd.cell(i,2,loc); cd.cell(i,3,ms); cd.cell(i,4,cu); cd.cell(i,5,pr)
    cd.cell(i,6,s).number_format='#,##0'; cd.cell(i,7,c).number_format='#,##0'
    cd.cell(i,8,f'=DATE(YEAR(A{i}),MONTH(A{i}),1)').number_format=MON
    cd.cell(i,9,f'=YEAR(A{i})')
    cd.cell(i,10,f'=LEFT(C{i},FIND("|",C{i})-1)')
    cd.cell(i,11,f'=MID(C{i},FIND("|",C{i})+1,50)')
    cd.cell(i,12,f'=LEFT(D{i},FIND(":",D{i})-1)')
    cd.cell(i,13,f'=MID(D{i},FIND(":",D{i})+1,80)')
    for j in range(1,14): cd.cell(i,j).font=bfont
widths(cd,{'A':12,'B':18,'C':20,'D':30,'E':16,'F':13,'G':13,'H':10,'I':8,'J':12,'K':14,'L':15,'M':26})
cd.freeze_panes='A2'; cd.auto_filter.ref=f'A1:M{LAST}'
R=lambda col:f'Clean_Data!${col}$2:${col}${LAST}'
SALE,COST,MONTH,YEAR,MGR,MS,LOC,CT=R('F'),R('G'),R('H'),R('I'),R('J'),R('C'),R('B'),R('L')

# ---------- MOM_Summary ----------
ms=wb.create_sheet('MOM_Summary')
head(ms,'MOM Summary (Month-over-Month)','All figures are formulas on Clean_Data. Blue/yellow cell = input you can change.')
put(ms,'A4','Selected month (Y2601 = Jan-2026)',bold,border=False)
put(ms,'C4',datetime.datetime(2025,12,1),inp,MON,yfill,align='center')
put(ms,'D4','=IF(SUMIFS(%s,%s,C4)=0,"No data for this month - data runs %s to %s","")'%(SALE,MONTH,'Jan-23','Dec-25'),Font(name=F,size=9,italic=True,color='C00000'),border=False)
put(ms,'A5','Previous month',bold,border=False); put(ms,'C5','=EDATE(C4,-1)',bfont,MON,align='center')
hdr(ms,7,1,['Metric','','Selected Month','Previous Month','Change','Change %'])
mets=[('Sales',SALE),('Cost',COST)]
put(ms,'A8','Sales'); put(ms,'A9','Cost'); put(ms,'A10','Gross Profit'); put(ms,'A11','Cost Ratio (Cost / Sales)'); put(ms,'A12','VAT 15% on Sales')
for r in range(8,13): ms.merge_cells(f'A{r}:B{r}')
for col,ref in (('C','$C$4'),('D','$C$5')):
    put(ms,f'{col}8',f'=SUMIFS({SALE},{MONTH},{ref})',bfont,NUM)
    put(ms,f'{col}9',f'=SUMIFS({COST},{MONTH},{ref})',bfont,NUM)
    put(ms,f'{col}10',f'={col}8-{col}9',bfont,NUM)
    put(ms,f'{col}11',f'=IF({col}8=0,0,{col}9/{col}8)',bfont,PCT)
    put(ms,f'{col}12',f'={col}8*VAT_15!$C$4',bfont,NUM)
for r in (8,9,10,12):
    put(ms,f'E{r}',f'=C{r}-D{r}',bfont,NUM); put(ms,f'F{r}',f'=IF(D{r}=0,0,E{r}/D{r})',bfont,PCT)
put(ms,'E11','=C11-D11',bfont,'0.0%;(0.0%);-'); put(ms,'F11','n/a',bfont,align='center')
for r in range(8,13): ms[f'B{r}'].border=box

put(ms,'A14','Full monthly history (Jan-2023 to Dec-2025)',bold,border=False)
hdr(ms,15,1,['Month','Year','Sales','Cost','Gross Profit','Cost Ratio','Sales MoM Change','Sales MoM %','Cost MoM %'])
months=sorted({datetime.datetime(d.year,d.month,1) for d,*_ in rows})
r0=16
for i,m in enumerate(months):
    r=r0+i
    if i==0: put(ms,f'A{r}',m,inp,MON,align='center')
    else: put(ms,f'A{r}',f'=EDATE(A{r-1},1)',bfont,MON,align='center')
    put(ms,f'B{r}',f'=YEAR(A{r})',bfont,'0',align='center')
    put(ms,f'C{r}',f'=SUMIFS({SALE},{MONTH},A{r})',bfont,NUM)
    put(ms,f'D{r}',f'=SUMIFS({COST},{MONTH},A{r})',bfont,NUM)
    put(ms,f'E{r}',f'=C{r}-D{r}',bfont,NUM)
    put(ms,f'F{r}',f'=IF(C{r}=0,0,D{r}/C{r})',bfont,PCT)
    if i==0:
        for c in 'GHI': put(ms,f'{c}{r}','-',bfont,align='center')
    else:
        put(ms,f'G{r}',f'=C{r}-C{r-1}',bfont,NUM)
        put(ms,f'H{r}',f'=IF(C{r-1}=0,0,C{r}/C{r-1}-1)',bfont,PCT)
        put(ms,f'I{r}',f'=IF(D{r-1}=0,0,D{r}/D{r-1}-1)',bfont,PCT)
rl=r0+len(months)-1; rt=rl+1
put(ms,f'A{rt}','Total',bold,fill=tfill); put(ms,f'B{rt}','',bold,fill=tfill)
put(ms,f'C{rt}',f'=SUM(C{r0}:C{rl})',bold,NUM,tfill); put(ms,f'D{rt}',f'=SUM(D{r0}:D{rl})',bold,NUM,tfill)
put(ms,f'E{rt}',f'=C{rt}-D{rt}',bold,NUM,tfill); put(ms,f'F{rt}',f'=IF(C{rt}=0,0,D{rt}/C{rt})',bold,PCT,tfill)
for c in 'GHI': put(ms,f'{c}{rt}','',bold,fill=tfill)
widths(ms,{'A':14,'B':9,'C':16,'D':16,'E':16,'F':12,'G':17,'H':13,'I':12})
ms.freeze_panes='A16'
MOM_R0,MOM_RL=r0,rl

# ---------- MOM_Trend ----------
mt=wb.create_sheet('MOM_Trend')
head(mt,'MOM Trend Chart','Monthly Sales vs Cost, Jan-2023 to Dec-2025 (source: MOM_Summary)')
lc=LineChart(); lc.title='Monthly Sales vs Cost'; lc.height=10; lc.width=26
lc.y_axis.title='Amount'; lc.x_axis.title='Month'; lc.y_axis.number_format='#,##0'; lc.x_axis.number_format='mmm-yy'
lc.y_axis.delete=False; lc.x_axis.delete=False
lc.add_data(Reference(ms,min_col=3,max_col=4,min_row=15,max_row=rl),titles_from_data=True)
lc.set_categories(Reference(ms,min_col=1,min_row=r0,max_row=rl))
lc.series[0].graphicalProperties.line.solidFill='1F4E79'; lc.series[1].graphicalProperties.line.solidFill='C0504D'
for s in lc.series: s.smooth=False; s.graphicalProperties.line.width=22000
lc.legend.position='b'
mt.add_chart(lc,'A4')
bc=LineChart(); bc.title='Sales MoM % Change'; bc.height=8; bc.width=26
bc.y_axis.number_format='0%'; bc.x_axis.number_format='mmm-yy'; bc.y_axis.delete=False; bc.x_axis.delete=False
bc.add_data(Reference(ms,min_col=8,min_row=15,max_row=rl),titles_from_data=True)
bc.set_categories(Reference(ms,min_col=1,min_row=r0,max_row=rl))
bc.x_axis.tickLblPos='low'; bc.series[0].graphicalProperties.line.solidFill='2E7D32'; bc.series[0].smooth=False; bc.legend.position='b'
mt.add_chart(bc,'A25')

# ---------- Manager_Share ----------
sh=wb.create_sheet('Manager_Share')
head(sh,'Manager | Salesman - Sales Share','Share of total sales; pie charts built from the tables below (formulas on Clean_Data)')
mgr_order=pd.DataFrame(rows,columns=['d','loc','ms','cu','pr','s','c']).assign(m=lambda x:x.ms.str.split('|').str[0]).groupby('m').s.sum().sort_values(ascending=False)
put(sh,'A4','Table 1: Sales share by Manager',bold,border=False)
hdr(sh,5,1,['Manager','Sales','Share %'])
for i,m in enumerate(mgr_order.index):
    r=6+i
    put(sh,f'A{r}',m); put(sh,f'B{r}',f'=SUMIFS({SALE},{MGR},A{r})',bfont,NUM); put(sh,f'C{r}',f'=B{r}/$B${6+len(mgr_order)}',bfont,PCT)
mr_l=5+len(mgr_order); mr_t=mr_l+1
put(sh,f'A{mr_t}','Total',bold,fill=tfill); put(sh,f'B{mr_t}',f'=SUM(B6:B{mr_l})',bold,NUM,tfill); put(sh,f'C{mr_t}',f'=SUM(C6:C{mr_l})',bold,PCT,tfill)

ms_order=pd.DataFrame(rows,columns=['d','loc','ms','cu','pr','s','c']).groupby('ms').s.sum().sort_values(ascending=False)
t2=mr_t+3
put(sh,f'A{t2}','Table 2: Sales share by Manager|Salesman (all 55 combinations)',bold,border=False)
hdr(sh,t2+1,1,['Manager|Salesman','Sales','Share %','Rank'])
s0=t2+2
for i,k in enumerate(ms_order.index):
    r=s0+i
    put(sh,f'A{r}',k); put(sh,f'B{r}',f'=SUMIFS({SALE},{MS},A{r})',bfont,NUM)
    put(sh,f'C{r}',f'=B{r}/$B${s0+len(ms_order)}',bfont,PCT); put(sh,f'D{r}',f'=RANK(B{r},$B${s0}:$B${s0+len(ms_order)-1})',bfont,'0',align='center')
sl=s0+len(ms_order)-1; st=sl+1
put(sh,f'A{st}','Total',bold,fill=tfill); put(sh,f'B{st}',f'=SUM(B{s0}:B{sl})',bold,NUM,tfill); put(sh,f'C{st}',f'=SUM(C{s0}:C{sl})',bold,PCT,tfill); put(sh,f'D{st}','',bold,fill=tfill)
# Top-10 + Others table for the second pie
put(sh,'F4','Table 3: Top 10 Manager|Salesman + Others (for pie)',bold,border=False)
hdr(sh,5,6,['Manager|Salesman','Sales','Share %'])
for i in range(10):
    r=6+i
    put(sh,f'F{r}',f'=A{s0+i}',bfont); put(sh,f'G{r}',f'=B{s0+i}',bfont,NUM); put(sh,f'H{r}',f'=G{r}/$G$17',bfont,PCT)
put(sh,'F16','Others'); put(sh,'G16',f'=B{st}-SUM(G6:G15)',bfont,NUM); put(sh,'H16','=G16/$G$17',bfont,PCT)
put(sh,'F17','Total',bold,fill=tfill); put(sh,'G17','=SUM(G6:G16)',bold,NUM,tfill); put(sh,'H17','=SUM(H6:H16)',bold,PCT,tfill)
def pie(title_,labels,data,anchor,w=15,h=10):
    p=PieChart(); p.title=title_; p.height=h; p.width=w
    p.add_data(data,titles_from_data=True); p.set_categories(labels)
    p.dataLabels=DataLabelList(); p.dataLabels.showPercent=True; p.dataLabels.showVal=False; p.dataLabels.showCatName=False; p.dataLabels.showSerName=False; p.dataLabels.showLeaderLines=True
    p.legend.position='r'
    sh.add_chart(p,anchor)
pie('Sales Share by Manager',Reference(sh,min_col=1,min_row=6,max_row=mr_l),Reference(sh,min_col=2,min_row=5,max_row=mr_l),'F19',15,10)
pie('Sales Share - Top 10 Manager|Salesman + Others',Reference(sh,min_col=6,min_row=6,max_row=16),Reference(sh,min_col=7,min_row=5,max_row=16),'F40',17,11)
widths(sh,{'A':24,'B':16,'C':10,'D':8,'E':3,'F':24,'G':16,'H':10})

# ---------- Overall_Sales ----------
ov=wb.create_sheet('Overall_Sales')
head(ov,'Overall Sales','Totals and breakdowns - formulas on Clean_Data')
hdr(ov,4,1,['KPI','Value'])
k=[('Total Sales',f'=SUM({SALE})',NUM),('Total Cost',f'=SUM({COST})',NUM),('Gross Profit','=B5-B6',NUM),('Gross Margin %','=IF(B5=0,0,B7/B5)',PCT),('No. of Transactions',f'=COUNT({SALE})','#,##0'),('Average Sale per Transaction','=IF(B9=0,0,B5/B9)',NUM)]
for i,(a,f,fm) in enumerate(k):
    put(ov,f'A{5+i}',a,bold); put(ov,f'B{5+i}',f,bfont,fm)
put(ov,'A12','By Year',bold,border=False)
hdr(ov,13,1,['Year','Sales','Cost','Gross Profit','Share %'])
for i,y in enumerate([2023,2024,2025]):
    r=14+i
    put(ov,f'A{r}',y,inp,'0',align='center'); put(ov,f'B{r}',f'=SUMIFS({SALE},{YEAR},A{r})',bfont,NUM); put(ov,f'C{r}',f'=SUMIFS({COST},{YEAR},A{r})',bfont,NUM)
    put(ov,f'D{r}',f'=B{r}-C{r}',bfont,NUM); put(ov,f'E{r}',f'=B{r}/$B$17',bfont,PCT)
put(ov,'A17','Total',bold,fill=tfill)
for c,fm in zip('BCDE',[NUM,NUM,NUM,PCT]): put(ov,f'{c}17',f'=SUM({c}14:{c}16)',bold,fm,tfill)
locs=pd.DataFrame(rows,columns=['d','loc','ms','cu','pr','s','c']).groupby('loc').s.sum().sort_values(ascending=False).index.tolist()
put(ov,'A19','By Location',bold,border=False)
hdr(ov,20,1,['Location','Sales','Cost','Gross Profit','Share %'])
for i,l in enumerate(locs):
    r=21+i
    put(ov,f'A{r}',l); put(ov,f'B{r}',f'=SUMIFS({SALE},{LOC},A{r})',bfont,NUM); put(ov,f'C{r}',f'=SUMIFS({COST},{LOC},A{r})',bfont,NUM)
    put(ov,f'D{r}',f'=B{r}-C{r}',bfont,NUM); put(ov,f'E{r}',f'=B{r}/$B${21+len(locs)}',bfont,PCT)
ll=20+len(locs); lt=ll+1
put(ov,f'A{lt}','Total',bold,fill=tfill)
for c,fm in zip('BCDE',[NUM,NUM,NUM,PCT]): put(ov,f'{c}{lt}',f'=SUM({c}21:{c}{ll})',bold,fm,tfill)
cts=['Supermarkets','Hypermarkets','Hotels','Groceries']
c0=lt+3
put(ov,f'A{c0-1}','By Customer Type',bold,border=False)
hdr(ov,c0,1,['Customer Type','Sales','Cost','Gross Profit','Share %'])
for i,l in enumerate(cts):
    r=c0+1+i
    put(ov,f'A{r}',l); put(ov,f'B{r}',f'=SUMIFS({SALE},{CT},A{r})',bfont,NUM); put(ov,f'C{r}',f'=SUMIFS({COST},{CT},A{r})',bfont,NUM)
    put(ov,f'D{r}',f'=B{r}-C{r}',bfont,NUM); put(ov,f'E{r}',f'=B{r}/$B${c0+1+len(cts)}',bfont,PCT)
cl=c0+len(cts); ct_=cl+1
put(ov,f'A{ct_}','Total',bold,fill=tfill)
for c,fm in zip('BCDE',[NUM,NUM,NUM,PCT]): put(ov,f'{c}{ct_}',f'=SUM({c}{c0+1}:{c}{cl})',bold,fm,tfill)
bar=BarChart(); bar.type='col'; bar.title='Sales by Location'; bar.height=9; bar.width=16
bar.add_data(Reference(ov,min_col=2,min_row=20,max_row=ll),titles_from_data=True); bar.set_categories(Reference(ov,min_col=1,min_row=21,max_row=ll))
bar.legend=None; bar.y_axis.number_format='#,##0'; bar.y_axis.delete=False; bar.x_axis.delete=False
ov.add_chart(bar,'G4')
widths(ov,{'A':30,'B':16,'C':16,'D':16,'E':10})
ctrl=ct_+3
put(ov,f'A{ctrl}','Reconciliation check',bold,border=False)
put(ov,f'A{ctrl+1}','Clean_Data total vs original Data sheet'); put(ov,f'B{ctrl+1}',f'=B5-SUM(Data!K13:K{ws0.max_row})',bfont,NUM)
put(ov,f'C{ctrl+1}',f'=IF(ROUND(B{ctrl+1},2)=0,"OK - ties to source","CHECK")',bold)
OV_CHECK=f'C{ctrl+1}'

# ---------- Cost_Ratio ----------
cr=wb.create_sheet('Cost_Ratio')
head(cr,'TTL Cost Ratio','Cost Ratio = Total Cost / Total Sales')
hdr(cr,4,1,['Metric','Value'])
put(cr,'A5','Total Sales',bold); put(cr,'B5','=Overall_Sales!B5',green,NUM)
put(cr,'A6','Total Cost',bold); put(cr,'B6','=Overall_Sales!B6',green,NUM)
put(cr,'A7','TTL Cost Ratio',bold,fill=tfill); put(cr,'B7','=IF(B5=0,0,B6/B5)',bold,'0.00%',tfill)
put(cr,'A8','Gross Margin (1 - Cost Ratio)',bold); put(cr,'B8','=1-B7',bfont,'0.00%')
put(cr,'A10','By Year',bold,border=False); hdr(cr,11,1,['Year','Sales','Cost','Cost Ratio'])
for i,y in enumerate([2023,2024,2025]):
    r=12+i
    put(cr,f'A{r}',f'=Overall_Sales!A{14+i}',green,'0',align='center'); put(cr,f'B{r}',f'=Overall_Sales!B{14+i}',green,NUM); put(cr,f'C{r}',f'=Overall_Sales!C{14+i}',green,NUM); put(cr,f'D{r}',f'=IF(B{r}=0,0,C{r}/B{r})',bfont,PCT)
put(cr,'A15','Total',bold,fill=tfill); put(cr,'B15','=SUM(B12:B14)',bold,NUM,tfill); put(cr,'C15','=SUM(C12:C14)',bold,NUM,tfill); put(cr,'D15','=IF(B15=0,0,C15/B15)',bold,PCT,tfill)
put(cr,'A17','By Manager',bold,border=False); hdr(cr,18,1,['Manager','Sales','Cost','Cost Ratio'])
for i,m in enumerate(mgr_order.index):
    r=19+i
    put(cr,f'A{r}',f'=Manager_Share!A{6+i}',green); put(cr,f'B{r}',f'=Manager_Share!B{6+i}',green,NUM); put(cr,f'C{r}',f'=SUMIFS({COST},{MGR},A{r})',bfont,NUM); put(cr,f'D{r}',f'=IF(B{r}=0,0,C{r}/B{r})',bfont,PCT)
cml=18+len(mgr_order); cmt=cml+1
put(cr,f'A{cmt}','Total',bold,fill=tfill); put(cr,f'B{cmt}',f'=SUM(B19:B{cml})',bold,NUM,tfill); put(cr,f'C{cmt}',f'=SUM(C19:C{cml})',bold,NUM,tfill); put(cr,f'D{cmt}',f'=IF(B{cmt}=0,0,C{cmt}/B{cmt})',bold,PCT,tfill)
cb=BarChart(); cb.type='col'; cb.title='Cost Ratio by Manager'; cb.height=8; cb.width=15
cb.add_data(Reference(cr,min_col=4,min_row=18,max_row=cml),titles_from_data=True); cb.set_categories(Reference(cr,min_col=1,min_row=19,max_row=cml))
cb.legend=None; cb.y_axis.number_format='0%'; cb.y_axis.delete=False; cb.x_axis.delete=False
cr.add_chart(cb,'F4')
widths(cr,{'A':30,'B':16,'C':16,'D':13})

# ---------- VAT_15 ----------
va=wb.create_sheet('VAT_15')
head(va,'VAT 15% of Total Sales','VAT = Total Sales x VAT rate. Assumes the Sale column is net of VAT (exclusive).')
put(va,'A4','VAT rate',bold); put(va,'C4',0.15,inp,'0%',yfill,align='center')
put(va,'D4','<- input (given by user: 15%)',sub,border=False)
va.merge_cells('A4:B4'); va['B4'].border=box
hdr(va,6,1,['Item','','Amount'])
put(va,'A7','Total Sales (excl. VAT)',bold); put(va,'C7','=Overall_Sales!B5',green,NUM)
put(va,'A8','VAT @ 15%',fill=tfill,font=bold); put(va,'C8','=C7*C4',bold,NUM,tfill)
put(va,'A9','Total Sales incl. VAT',bold); put(va,'C9','=C7+C8',bfont,NUM)
for r in (7,8,9): va.merge_cells(f'A{r}:B{r}'); va[f'B{r}'].border=box
put(va,'A11','VAT by Year',bold,border=False); hdr(va,12,1,['Year','','Sales','VAT','Sales incl. VAT'])
for i in range(3):
    r=13+i
    put(va,f'A{r}',f'=Overall_Sales!A{14+i}',green,'0',align='center'); va.merge_cells(f'A{r}:B{r}'); va[f'B{r}'].border=box
    put(va,f'C{r}',f'=Overall_Sales!B{14+i}',green,NUM); put(va,f'D{r}',f'=C{r}*$C$4',bfont,NUM); put(va,f'E{r}',f'=C{r}+D{r}',bfont,NUM)
put(va,'A16','Total',bold,fill=tfill); va.merge_cells('A16:B16'); va['B16'].border=box; va['B16'].fill=tfill
for c in 'CDE': put(va,f'{c}16',f'=SUM({c}13:{c}15)',bold,NUM,tfill)
put(va,'A18','VAT by Location',bold,border=False); hdr(va,19,1,['Location','','Sales','VAT','Sales incl. VAT'])
for i,l in enumerate(locs):
    r=20+i
    put(va,f'A{r}',f'=Overall_Sales!A{21+i}',green); va.merge_cells(f'A{r}:B{r}'); va[f'B{r}'].border=box
    put(va,f'C{r}',f'=Overall_Sales!B{21+i}',green,NUM); put(va,f'D{r}',f'=C{r}*$C$4',bfont,NUM); put(va,f'E{r}',f'=C{r}+D{r}',bfont,NUM)
vl=19+len(locs); vt=vl+1
put(va,f'A{vt}','Total',bold,fill=tfill); va.merge_cells(f'A{vt}:B{vt}'); va[f'B{vt}'].border=box; va[f'B{vt}'].fill=tfill
for c in 'CDE': put(va,f'{c}{vt}',f'=SUM({c}20:{c}{vl})',bold,NUM,tfill)
put(va,f'A{vt+2}','Note: Sale values carry no currency tag in the ERP export (8 locations in UAE/India/USA/UK/Canada); amounts are treated as one reporting currency, as exported.',sub,border=False)
widths(va,{'A':20,'B':10,'C':18,'D':18,'E':18})

# ---------- PQ_Steps ----------
pq=wb.create_sheet('PQ_Steps')
head(pq,'Data Cleaning Log + Power Query (M) equivalent','Clean_Data was produced with these steps (done outside Power Query; the M script below is the Power Query equivalent)')
hdr(pq,4,1,['Step','What was done','Rows'])
steps=[('1','Original rows in Data sheet (row 13 to last row)',f'=ROWS(Data!A13:A{ws0.max_row})'),
('2','Removed blank spacer rows',f'=COUNTBLANK(Data!A13:A{ws0.max_row})'),
('3','Removed month-label rows (e.g. "February 2023")',f'=COUNTIF(Data!A13:A{ws0.max_row},"*20??")'),
('4','Removed repeated header rows ("Invoice Date")',f'=COUNTIF(Data!A13:A{ws0.max_row},"Invoice Date")'),
('5','Valid transaction rows kept (Clean_Data)',f'=COUNT({SALE})'),
('6','Check: 1 - (2+3+4) = 5','=IF(C5-C6-C7-C8=C9,"OK","CHECK")')]
for i,(a,b,c) in enumerate(steps):
    r=5+i; put(pq,f'A{r}',a,bfont,align='center'); put(pq,f'B{r}',b); put(pq,f'C{r}',c,bfont,'#,##0',align='center')
pq['C10'].font=bold
put(pq,'A12','Other steps: removed empty columns C,D,F,H,J; split Manager|Salesman at "|" and Customer Details at ":"; added Month (1st of month) and Year; Sale/Cost already numeric.',sub,border=False)
m_code='''let
    Source   = Excel.CurrentWorkbook(){[Name="Table1"]}[Content],
    Skip     = Table.Skip(Source, 10),
    Promote  = Table.PromoteHeaders(Skip, [PromoteAllScalars=true]),
    Keep     = Table.SelectColumns(Promote, {"Invoice Date","Location","Manager|Salesman","Customer Details","Product","Sale","Cost"}),
    NoHdr    = Table.SelectRows(Keep, each [Invoice Date] <> "Invoice Date" and [Sale] <> "Sale"),
    NoBlank  = Table.SelectRows(NoHdr, each [Sale] <> null and [Cost] <> null),
    Typed    = Table.TransformColumnTypes(NoBlank, {{"Invoice Date", type date},{"Sale", type number},{"Cost", type number}}),
    SplitMS  = Table.SplitColumn(Typed, "Manager|Salesman", Splitter.SplitTextByDelimiter("|"), {"Manager","Salesman"}),
    SplitCu  = Table.SplitColumn(SplitMS, "Customer Details", Splitter.SplitTextByDelimiter(":"), {"Customer Type","Customer"}),
    AddMonth = Table.AddColumn(SplitCu, "Month", each Date.StartOfMonth([Invoice Date]), type date)
in
    AddMonth'''
put(pq,'A14','Power Query M script (Advanced Editor):',bold,border=False)
for i,line in enumerate(m_code.split('\n')):
    c=pq.cell(15+i,1,line); c.font=Font(name='Consolas',size=9)
widths(pq,{'A':8,'B':62,'C':12})

# ---------- Summary ----------
su=wb.create_sheet('Summary')
head(su,'Sales Analysis - Executive Summary','Source: ERP sales export, Jan-2023 to Dec-2025. Every figure links to the detail sheets.')
hdr(su,4,1,['KPI','Value','Detail sheet'])
kp=[('Total Sales','=Overall_Sales!B5',NUM,'Overall_Sales'),('Total Cost','=Overall_Sales!B6',NUM,'Overall_Sales'),('Gross Profit','=Overall_Sales!B7',NUM,'Overall_Sales'),
('TTL Cost Ratio','=Cost_Ratio!B7','0.00%','Cost_Ratio'),('VAT 15% of TTL Sales','=VAT_15!C8',NUM,'VAT_15'),('Total Sales incl. VAT','=VAT_15!C9',NUM,'VAT_15'),('Transactions','=Overall_Sales!B9','#,##0','Overall_Sales')]
for i,(a,f,fm,s) in enumerate(kp):
    r=5+i; put(su,f'A{r}',a,bold); put(su,f'B{r}',f,green,fm); put(su,f'C{r}',s,bfont,align='center')
su['A8'].fill=tfill; su['B8'].fill=tfill
put(su,'A13','Sales by Year',bold,border=False); hdr(su,14,1,['Year','Sales','Cost','Cost Ratio','Sales YoY %'])
for i in range(3):
    r=15+i
    put(su,f'A{r}',f'=Overall_Sales!A{14+i}',green,'0',align='center'); put(su,f'B{r}',f'=Overall_Sales!B{14+i}',green,NUM); put(su,f'C{r}',f'=Overall_Sales!C{14+i}',green,NUM)
    put(su,f'D{r}',f'=Cost_Ratio!D{12+i}',green,PCT)
    put(su,f'E{r}','-' if i==0 else f'=IF(B{r-1}=0,0,B{r}/B{r-1}-1)',bfont,PCT,align='right' if i==0 else None)
put(su,'A19','MOM snapshot (selected month on MOM_Summary)',bold,border=False); hdr(su,20,1,['Metric','Selected','Previous','Change %'])
for i,(lab,row) in enumerate([('Sales',8),('Cost',9),('Gross Profit',10)]):
    r=21+i; put(su,f'A{r}',lab); put(su,f'B{r}',f'=MOM_Summary!C{row}',green,NUM); put(su,f'C{r}',f'=MOM_Summary!D{row}',green,NUM); put(su,f'D{r}',f'=MOM_Summary!F{row}',green,PCT)
put(su,'A24','Month shown'); put(su,'B24','=MOM_Summary!C4',green,MON,align='center'); put(su,'C24','=MOM_Summary!C5',green,MON,align='center'); put(su,'D24','',bfont)
put(su,'A26','Key findings',bold,border=False)
a_=f'Overall_Sales!A21:A{ll}'; b_=f'Overall_Sales!B21:B{ll}'
finds=[
 f'="Total sales "&TEXT(B5,"#,##0")&" at a cost ratio of "&TEXT(B8,"0.0%")&" (gross margin "&TEXT(1-B8,"0.0%")&")."',
 f'="Top manager: "&INDEX(Manager_Share!A6:A{mr_l},MATCH(MAX(Manager_Share!B6:B{mr_l}),Manager_Share!B6:B{mr_l},0))&" with "&TEXT(MAX(Manager_Share!C6:C{mr_l}),"0.0%")&" of sales."',
 f'="Top Manager|Salesman: "&Manager_Share!A{s0}&" ("&TEXT(Manager_Share!C{s0},"0.0%")&" of sales)."',
 f'="Top location: "&INDEX({a_},MATCH(MAX({b_}),{b_},0))&" ("&TEXT(MAX({b_})/B5,"0.0%")&" of sales)."',
 f'="Best month: "&TEXT(INDEX(MOM_Summary!A{MOM_R0}:A{MOM_RL},MATCH(MAX(MOM_Summary!C{MOM_R0}:C{MOM_RL}),MOM_Summary!C{MOM_R0}:C{MOM_RL},0)),"mmm-yy")&" ("&TEXT(MAX(MOM_Summary!C{MOM_R0}:C{MOM_RL}),"#,##0")&"); weakest: "&TEXT(INDEX(MOM_Summary!A{MOM_R0}:A{MOM_RL},MATCH(MIN(MOM_Summary!C{MOM_R0}:C{MOM_RL}),MOM_Summary!C{MOM_R0}:C{MOM_RL},0)),"mmm-yy")&" ("&TEXT(MIN(MOM_Summary!C{MOM_R0}:C{MOM_RL}),"#,##0")&")."',
 f'="VAT @ "&TEXT(VAT_15!C4,"0%")&" on total sales = "&TEXT(B9,"#,##0")&"."',
 f'="Data check: "&Overall_Sales!{OV_CHECK}']
for i,f in enumerate(finds):
    c=su.cell(27+i,1,f); c.font=bfont
pie_s=PieChart(); pie_s.title='Sales Share by Manager'; pie_s.height=9; pie_s.width=14
pie_s.add_data(Reference(sh,min_col=2,min_row=5,max_row=mr_l),titles_from_data=True); pie_s.set_categories(Reference(sh,min_col=1,min_row=6,max_row=mr_l))
pie_s.dataLabels=DataLabelList(); pie_s.dataLabels.showPercent=True; pie_s.dataLabels.showVal=False; pie_s.dataLabels.showCatName=False; pie_s.dataLabels.showSerName=False
su.add_chart(pie_s,'G4')
lc2=LineChart(); lc2.title='Monthly Sales vs Cost'; lc2.height=9; lc2.width=14
lc2.add_data(Reference(ms,min_col=3,max_col=4,min_row=15,max_row=rl),titles_from_data=True); lc2.set_categories(Reference(ms,min_col=1,min_row=r0,max_row=rl))
lc2.y_axis.number_format='#,##0'; lc2.x_axis.number_format='mmm-yy'; lc2.y_axis.delete=False; lc2.x_axis.delete=False; lc2.legend.position='b'
for s in lc2.series: s.smooth=False
su.add_chart(lc2,'G23')
widths(su,{'A':34,'B':18,'C':16,'D':13,'E':13,'F':3})

# ---------- order & save ----------
order=['Summary','MOM_Summary','MOM_Trend','Manager_Share','Overall_Sales','Cost_Ratio','VAT_15','Clean_Data','PQ_Steps','Data','Sheet1']
wb._sheets=[wb[n] for n in order]
wb.active=0
for w in wb.worksheets: w.sheet_view.tabSelected=(w.title=='Summary')
tabs={'Summary':'1B2A4A','MOM_Summary':'2E75B6','MOM_Trend':'2E75B6','Manager_Share':'2E75B6','Overall_Sales':'2E75B6','Cost_Ratio':'2E75B6','VAT_15':'2E75B6','Clean_Data':'7F7F7F','PQ_Steps':'7F7F7F'}
for n,c in tabs.items(): wb[n].sheet_properties.tabColor=c
wb.save(OUT)
print('saved')
